# DouyinHelper 微验版（GitHub Actions 构建）

这个工程用 GitHub 的 macOS 机器编译，不需要你自己有 Mac。

## 一、建仓库并上传

1. 打开 https://github.com/new
   - Repository name 填 `douyinhelper`
   - 选 **Private** 或 Public 都行
   - 点 **Create repository**
2. 进入新仓库，点 **Add file → Upload files**
3. 把本文件夹里的这些**文件**拖进去（不要拖文件夹外壳，拖里面的文件）：
   - `Tweak.xm`
   - `Makefile`
   - `control`
   - `DouyinHelper.plist`
4. 点 **Commit changes**
5. 再点 **Add file → Create new file**，文件名填：
   ```
   .github/workflows/build.yml
   ```
   把仓库里 `build.yml` 的内容整段粘进去，点 **Commit changes**

## 二、编译

1. 点仓库上方的 **Actions** 标签
2. 左边点 **build-dylib**
3. 右边点 **Run workflow → Run workflow**
4. 等 5~10 分钟，出现绿色对勾
5. 点进这次运行，页面最下面 **Artifacts** 下载 `DouyinHelper-dylib`
6. 解压得到 `DouyinHelper.dylib`

## 三、注入

用 TrollFools（或你之前注入原 dylib 的工具）把新 dylib 注入抖音：
- Bundle ID：`com.ss.iphone.ugc.Aweme`
- 注入后 TrollFools 会重新签名

## 四、功能

- 启动抖音时检测到抖音助手模块（`DYZSAuthorInfoView`）就弹卡密窗口
- 公告、设备码、验证、解绑
- 验证成功才放行；5 秒心跳，失效重新弹窗
- 微验参数：APPID 85778 / APPKEY z8h94W9XH4KYWh9z / RC4KEY 3N443KVZtlv85778
- 关于作者区域：隐藏“完全免费分享”“TG交流群”“基于DYYY”，头像替换为指定图片
- 点“关于作者/联系作者”弹窗显示微信 `lz3094448385`，可一键复制

## 五、如果构建报错

把 Actions 里红色那一步的报错贴出来，需要改 `Tweak.xm` 里对应行；
第一次构建大概率会有 1~2 个编译错误，改完再点一次 Run workflow 即可。
