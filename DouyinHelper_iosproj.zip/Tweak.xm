#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <objc/runtime.h>
#include <string.h>
#include <stdio.h>

#define APPID   @"85778"
#define APPKEY  @"z8h94W9XH4KYWh9z"
#define RC4KEY  @"3N443KVZtlv85778"
#define APIURL  @"http://wy.llua.cn/api/"
#define WECHAT  @"lz3094448385"

static NSString *const kAvatarB64 = @"/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAQCAwMDAgQDAwMEBAQEBQkGBQUFBQsICAYJDQsNDQ0LDAwOEBQRDg8TDwwMEhgSExUWFxcXDhEZGxkWGhQWFxb/2wBDAQQEBAUFBQoGBgoWDwwPFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhb/wAARCAEAAQADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD1i3jVbZArNIAgUmTkk45JPU1XjeR4Y3azNnPKhLRlVLx9QORx3B9qqaTprprC3p1TUZESPZFatMoh77iwA+Y8jBzxgVpWTW92gu4WEgkXG8gjIViANp991dh5dywgVLcDIbCYDSgFm46n1Pc1l3viHRoNLur2e7SSHT5RDdCOHe4kyF27Bk5JIxjNXhJhlUrluQm5eOnX2qC3jZL5p0gjXBQxMqAFiCWJY4z95uPpmpC5cilSVFkjAZXXeG2YzkZBx1zz0prXlu8CzQK0iNJ5QCR5+YEg8HHfPNQRTyG5lSSRmKMqfNGQXJGT83RjyOg47024RvtbT/aZyhiEYhyAi4z8w4zu6DrjA6UDuWpWjkCkQxStC5ZA2PkJGM/XH86gEtlcTSlPKmkDCGYbuFxyVx2+9n3zVSaV4kUpDMXkkXftAyV6bsegAz9M0sQhCv8AZ1Amn5aZAC3154oC5qW0gMkjRqqur4baB1x/hiq8V3LdNDJZS28tszsXcAdBkbV45579sVDYPBAZIFVRKx86UjOXZsjJz3+XHHpUyOZV+eOQMrbQWO0EDGCOeR/gaAuOuUhls51nt8xbGEibMiQY5BGMn8PWqmlMTp0bwW9pbWnlEIsROIuflUKRjp19DxUyOftLHznYNhTGw4Xrk/rUeq3VvYxtJPIIYFA3MoxhmOAT9SR2oC5YkzKqsLdJJEBH71QCePy5pbxQx8wfKwGWUBf3nHQ56Y9qrmddjB4n2Jh97sOuemB6VVknZbV5gyuoJLlSflz0GDyTz2oEfHn7eusT33j6y0kOmy1ikuZFVcYLYIz7hNtfPpr0v9p/Wpb/AOLuqz5DCRDGuQDtXdgY/BQK80JzWE3dnoUlaCEoooqDQKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP1GtvJkklyj7Y5sbRlCMAHt95Tkn3zVfxDe6/a6fbReH9Pj1S+muI42EzeWiRc72OOhA6Co7S+a7uNTgRnQwS/Z1lQYXPlggr643jn6VbgH2e0htkkd/KRU82X52YAAEse7HHX1rrueWWrht8jLtEpDuAokwuQMYb8+nrTyHbbEqruH12rjHBP1PFU4N0pDySrIgmMu5E2HGCMN/e56nj9KdbYjtoreSbzvLUlmfkn5sjr6f0pAW7slWXfJgKcopTJwOuOe/6e9V74RvCykA7yC3OM46fyFRNOxDtLIrsw2s4PCj0C+lU5LhivKPkDn/DFADBc2dkYLayjdY587Nm6QscZd2bnGT3JxyBSwZgEce97hC7vK20jYDkgDnoDgVRluWluN0kg+0IgLJIzDyy33iwU4OApAz3+lQ3t8lhaNeXDTOrMiKkR3EkkKNoHPVup9OKLCudNbzLIW3qqgdTu5I7cevtTPM/4nSotxNj7OT9nWMGP7332bqD0AA6/hWMs97/aYkjuUW1hicyW7REPMxC7dpx2IbOfpzV2xuTJbR3F1aNbXMkSl4phiSLuVNAXNLeG3FiwKDg4wQPaoZJYo5y0qo6j958/TPq2eO1Ur26k8gqkgjnlQ7VznnHr0wKqlJRZeTfXEVwxjWOVDhomOPmYnqc88YxQMumeV5HknCeWGAjVG3kjHO4Aeuf0rK8U3y2um3D+a8Xmk4dVIK8c8Y9utOS9injWSGPYgyAuwjOCRkZ6D047VgeOJ/8AQZDLcSOscJbK5UFjjjJ6rnigD4a+Lt4t948v5lcOTIQzhcBmySTj8a5mtz4hQiHxXex+csxSXaZFGATtBP6kj8Kw655bnpR+FBRRRUlBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB+jVrqP2i+1DS1nktRAV2yWyKJFDYO4HBUtjjkcYHFW9sDXYv7m6u5JraIxW0SsFQlidzuo4LABR6cnpXLaTq0Fxo9mbO8WQSB7maZ1EYnGD0B74VVGecgipzqgI2qrZClm9MZ6+1ddjyrnT/wBpTiNfJjkfILO7MAsQA+8c84zgYGTzRFfMkANyqZX7smCqsccsBnjnIxk1y0d9axxNJFDHEXxI5ckyNnAyCTxwB+FJbapuULAC7BCWzyqe7HsMnrSGdLPfSsUxEWy3LDP3QCTxnOen50n2r92Cd6huQp4x/WsK1uwlzIBOWkZsMPMxGFGBle5B5PPtS3N1KI9wGCADkBvn5HIHfPOTTsJs0GvlkvjaGc7I1WR4skA7iQDn1+Uj19Ku2UzI4kVFMqKxWQybREcH5t3cgZP1xWHutbhRDf2ttdxQzmYw3Cbk37AFJAPzYzkDse1WhMrkbZRAq8lhHnC+ig8c9OePr0oEaHnSxxhxsSPHVi2G7DHc88cnJpJJ447Q+Ux86ZeZn+ZgeeB6qM8Csu4uvMCsPnLnJHlE9MnnPb14A+uapS3jeazFXCLwWKnae/XuM46UWA3hdpEDBFJJMsYCGSQ/eH95vQ01r2wbNxNapLcINsLyAMsYPLfKeCeBz2rnoLm4EyxrIT5jDaWARckdTngdep7UlrepNAjx25xg732NiUgnJBPJA4HHGBT5RXNrVLuXYXkEysoARWUF2wOFx24xWdqxjMc0F/E9qrWYV4ZZOVyQST2HX8KzZLh2hJedi6glQwPHPQnuT7dKkmmJuobi7gka5jkRfs9wgeJ1wc71bnnI46dafKM+Nvjhp7aZ8S9TtJE2usoY4GFbKj5h6g9fxrkq+hf2ufCsmpWaeLbSA+dZRrHe4H3oi2Ff/gLHb9CPSvnquWatI9KlLmgmFFFFQaBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB93ak9g0638enQ6fYJ5am0tn2ruVdxPzdATgn8e/NUrJ8RxG7USIHzIMEb1zkg85ORgcdMfWkV7cnZbQrEkaqjJyV3gAkkHrnk/jU0k0F5eyy3USsSHaJYW2Ijnocf3Rknb3rtSueSNmJKyIZvLAUAAMPl5PBB5zxwOnrVgR+TI0IZsLnZskBB5GNxHDcenfFMW18jTRK8qiOSfYkIX95kAFnLDkDlQPfdTJ5oojgcKuC7JlgcnoOOSTgVYF61kuXlR7aPzlQFnYsFEaAHLcn5j04HPWp1ERZmnLKRlgkbDLMOgYnnHcj2WqaMUPmEK7EDBXOEH93Hc9OlOeY7wMySKoXD+VtUMd2Ez3PfjtjpWYWJNF3reX8gDsrShiCAUGABgnsRxx7ir8zvMC2WXcMYVfbgL2z6elU7aQNaBGEqj5vK+YKrMXOSP8AZzxzz154oEskzojAbIss/wAwGeMfiMkcd6VhbFySR0lZFLKgG0EsCzkY+VvUDA579qo3VxNJGkCs77XIIYkhFJLH2H196laJ3mDiVQ7sBGMFQvGM5/HNQSl/NdYljIQDz3QFASSQAc9enbjimiecYsbyTnyWzjLOjDOVBz1zxwKGuZpZhvaX5AVBdmdI1x8qj8sY9qJpbpLf5RKIwyrhFLZPOMKB8wHPzelSRj/RxJO6rBvUtExZWmJzkgjPHBGfeqTDnKn2G/nuHvF1aC3tbWHm2lizLcOTjI7DB5qzb2yyPJJ5+6Tk7pWIduAMsADjk8DNFyzsZCV8tAOI40IOOOx6duvWiFiJjJHIFaX74OX28dDn6VRVzK8S6db6ppdzp9/JG0c8BVjGuwLnjaQevqcV8ceO9BuPDPi290S5IZrWXarr0dTyrD2IIr7PkjuBbK88UoikY+W7D5X7nb9M15J+1D4LXVfCY8VWNvtutKG24wnM0JP67OD9CfSsasLq6OnD1OWVn1PnQdaV1ZGKsCCOxp9r5f2hVlO1GO1mxnaD3/Ctfxpod1ot+trMBJsjUrPHkpOh5Vhn8j6EEVzWO4xKKDRSAKUilQZyO9JmgBKKKKACiiigAooooAKKKKACiiigD7luJjPbQxyuzxxKFRBkAoWJYA8YByabc3ED6mStqI45susMZOIxkfLnsMH9KgdZ4pokeDc7x58s8+Wm3O4+nykfjTkFkHfdbSNelP3EnmFUiTI3HZ0bJwOTwK7onkkzJsXLqMlcgEnJGf0706O6KSKYnWLDl41jYqIWzgY9+AKakFykTSyPC6POwgMLZJxjG70+9x6ihmAu/NBdNmAsgGNufccbsf1obAlhLIdm2GQAb3JdtpAxgY4555/+tTbu4S3sWFtvjk582TeT5hI2jA7DHHHWpI4HaBihKoCVxng9+9Q3Ec3lwweRIZbq5SOEBSS2X4Ye3B/L8aTAuSzw3moSO91LbPbKu2C3t87j0VOwUAAk45PpzU6ohYCcf6sK5EffnoT+P9Ks2sxMZgS4UpFM0iyohAZzgFtw+8flHPOPpQyRhy0m1QAuS3O8k8D+lIBTBtiDtMj+cD+7Kn91joSe+euPSoy1w8Q80GOEFtkpiOHyQDz6ce+MVJcxMSscofyiSUMb8ttxknjIHYE4zVDVOZ9w8xc/KxQjJ5568Zxx9KCXYWK8IYyws+11KecvLMoXG0N12+351GbdiT5l3CYsKjsp/er8uWGw84HADdzUhlZyzKsQYdVTgtwFxgce/HSofMWGIFER2HzszJhnJ98k4HQY9M4oTsCd+hLs8qFnEkjRFMlgfmfkAbhnj196bZDypYZJYI5Ygwd4S52v7HnnPoKZFL+9aUxIRyu1l749M8etMgkZ4gsoCqMrDvXO49yPpTbG3YdeRLK0Yjg8t2B85GPOd3G0ent2AqKXM1v9jlL+WUKrGV3ABhydvfIqWZgZ5V/fHcgLIFxjAJ79sVXzGkBjivLi5JKmSWZFDbv7oIP3RwKVxrQ+ZfjB8Mp9A8RTvpcby6fdsWsm4G1uT5RHYkhtvrgDrVnwdajxX8L5LAxK1/om5AAxV2hJDnPqFK/hntX0R4n0fTtZsJ9Pv7fzLCUbWRXIIbjDg9cggEe4rjfD/gG30vVLiWZ5BHcqI5JgebofdL8dGHU/U+pqeTXQ7IV7qzPnj4iaJ/ZWpxFJBKk0eDIowpdeDj6jY3/Aqw7a0llikcDARCxNe1fFXwzJc/CaK+iAebTZYY/lX7/AjJ/JR+VefeHLQDwrqjzWxSeGEASE8MrMvBHqO1YyhrobxkmcfS4PocVZ8kE5NWbaENHtI+lZXLMwClKkdq247EHotRXtsELe9FwMiinSrtcjtTaYBRRRQAUUUUAFFFFAH3PZSrHbSQ29vGgniVZioyzkOH3ZPfhRx2AqOANGnkyXDwRSyKW6HjnBxxk43VbgsejpsSJMA7wS5J6Ec+xyfb1NSuTG4Y224OCgyoYgHjcP85rtTseUkZ7QWyMjyrcFSSZF8wbQBjAT0PrnuRT2tx5GNr7vMxyRsAA9uSentU8toyXB86GI3O0LsJwFOec546457EVNawJHOWI2twxkOdx9h2wMk560mxjLOI7wCxxj7pGcjP8Ad7/T61p6XDA0zNJNcKURiBCQoJPAXkcDuelR2QjiErh2WWPBdmPCjHb04q5axqRmCFAzc7gcM3pk9OKQrEqoLkkSJJthwkO75QowMhf4cdAcD8c0jYgn8xWMbbcBlGSeCCB+fWkuHRGRZJdrEEqG4zjH5DkU7zGaKVnKhUbaCO4GO3fntSJK8qSRRSK0rAyn7gPGPf8AKs+40+QnfJCEhf5ot0ql9o4OV6g5wBnk8kcVqzLvcA7CV6FuCPwqtIhaZ+XX1kJyD+Ht/hTRKWpnNbrFBIQ5AzudnG4pjpnA68VFbxHUI4WilNqk20+ZLGwWPAPBHcnB9Oa045baK2W5iCTRAqQzPu3dlyRwQDzjHtSzO9zbi6nlknaVgN78lumDkdv6UyzG0QpPAyC4gIa4K+c0ePKK5BGcZ/KrDJHPOzlXYxEskjSAFRnuvQ59B3q9qAdhGfIihURpHthUKGwOpA6k9Se9SJAklp5MsG1fTOw89cjv/SlcDLvkWRlkjJLyDD4zknHBx0Axj8ar6bbrLGN8DSMAXXDlSQOOnetZLe2SdIYFgtzMCRJGhYquOnY4HHHvTLCESur2cMFqmMZ2si7hnLbQSxJ656GgTM5ISs8ZeCW4w37y2kQqE/rjuajvYpWiZ5rNozIjBEKEH/ZYfzBrYu4RM4MshLH+8N7SP1xnjJJp0VnNGokcMQozKwOVA9+f5U7oZxenaNG/hP7DPHtBdnC4zjbMzDPvwa8y+L+gRaR4VvpoItv2i9eMY6bFZiB+HFe16ZZ3S6VGbgmO4QFtqjP3nZufTGa8+/aJMQ8KpbgYZpWkOevJNTLY6KMrzsfN8kaKmT3pbJgHC571W1WZhKVGMA4qCCco4LHvXGdx1Vqo2A45qjqkZB9Kt6POJYAc1HrGPrQBzV0nzZ7VBVy8AXIqoOppoBMUuKWii4DTRSmkpgFFFFAH3vD50gQk+WrAfKeOCM59c0+QhZVQKxbBB2qSQP6ZOOtPnmcyCUzsHKbRCIwdxPJff1BHAx3yaifUo/tb2hkAcpvKZ/h3cE/iOK62eWgiWFmd/OCOgCOeDs/iPB74Ipl9fWMDmeeRvLaHcBGC5YZAyAAfXtVa5lSeGW0UQkSHYzeUVA3AZ3EdTgnGOgxVmK5+zzxJBGsKeYuxVAIQDJGM9MYxSAvMEZgyzAZAbaFVlK9RlT3PTJ6ehqxaSOksgaMIygDIGFckZOD6Dj86zJIrQ38l7IC0kyCOUFyNyDJ2nGMck9PWrFt9tZD9qVYo1wIk3fOuQN24djnjvwKYF+O4Xz3jMcUko2n5m+ZF6njockLwfSo4L6C3RpldYtspBkLY+fPBz2OcdKqzXFyymD5kgYho2SQHe2OePpxn3ptmRaIW8lRICzKGTfyc44PfkkH6UieUlN0kqKsEL3sjMdwgyzStkDBOe2SfwOamMd5OvyTxIW6gsSiKOp2/xE57f0qlHep53loYw8JCyIDzGcZ5Hr/Wp7eVgfNLgb+SmcED+8fpjigdjU837PKbiJIoVVCOI1VEBGCNoGAMZ6CoZ3Es+98bicllUdfam29yJFSaIxyAAMpPQ+h96rPMDIS7NjuVTcQaBKNhI/Ke5ykCIiDbkoRhj3XPf/Gp0eQRsFaSUKeFUEk46ADuahju/OvD5jrKI+MMuQD2OPXp+VWkZgiyTThyRlBGcGNey59c/wA6BkMLFp5JJkVXbIyRllGensfWm3bzhPMie6uZWKxgEjCqMD0H/wCoUqxpO7CB33rlQDlsH1bHXHWob13hg81EaRxgDYMZ59D0oETySiYszwCR2YhVKj6ZFOxCg3SSRkNxtIxj2PrUU0ygs8Bd8AYyPmJxziob8rFbF/PBBx+8VcbCe3PegTTJJBtncgqFOCyhsZ9K+ev2ptYmg1h7AqU2kMgYdVI4P0ru/EPxk8M6VqE2nz/aBNGMRsVXy5D/ALRHI59jXn3xV8b+EfE0FrB4littSKJvSTSmeJ7fI5j8xidwHoV6+lZSqRa3O2hh6sXzNHhFxIzyFmPJOaYxzXodrH8It+Z7bxBjuDex/wDxFcvr+g/ZLh3tXZrdnJiL9dh5XP4EVimjraa3E8MTlflJ6Vo6ntKbs9azNMj8iPJzk1YuZ90fXpSBRbMm7ILYPeq3erF397Oe9V6AasFJmlpMU0ICcikpTSUwCiiigD7ennvv7UVUit2s/LMkxluNrDBGNo7nvtp91fsLWSKSUJbnD5KcA4wSeOvXgGqYaUzK1wdgI+clssfUDHfsPWop7heZYS4ReRzkoOo/HFdR5aLP22HO1XbEbbEAYqvPT5e2ePw4qeK43yI+9kCZbhc7uD69vf2rGlmHmAPKGAbCqybT65Zh1POOnapYVMtyihF8uEFyzuVJPQAL3+8eD6UAdFazRyOu4kk5BPTB+nSrsMhMO1FLsAPlVgfyJrm4J5FugjQTFdhYSn7u3IGffnjp2NaunSubZ2j++wITd0B7EjrQBYF5bGx88hjG6lwR1K+gH50yPcYDLK8bKrgMOR5bf7WPrwBnpzUOpNGLKWF5o2lEQUGKPauSANwHYE8/1qqT5aNEHJQLguCW+XOBgdPT69aALIlaMbB9naIHKMY/LmkZvVRzhQMfMe/HWrcFy0rLFHD5pbqvqB1/D1rnXYmQOZDIxXcSRgjn9cZq/Zs53fP8/IUDuO/NAG3IsSk3FpMjecN/lwNiOH+ERqvbGOQM1RupbiFtl2DazggSxOQSp6lTjjPb2qkZbpYhtiVRuG1geG9cdyaz9R1C4Ziz3CupLKGfG456k/n1pok3YGtURPJvCWmKvIzJ9x/7o9eAOfetOwkcP9oC3MdtGQPNOGG4joOnP/1q45Lya2JhhuBtiYruAyCMYJz6VqaVPc+V+8mjKglVVWBIPHX0osBthprdW8tFI2PtA5kmbuf9mi0v5o7dZLqCS3eJdzLKQw4HO71bvVCCSYy+aGjMJGN/8SnsNvfvTNT1ZNNsJrm71SOG3hgJuZLobVWPuSffpj6Uho8j8RfHptH8TzWaWNnfWAkb94u5JAM9iMj9Kr+Ov2i7NtBktPCunSreTAKbi7jVo4hjnC/xN2BOAOteUfFk+G9Q8Xz3XhOO6jsHOSJj8pb1jB+YL/vc/SudWzQD5nJrG0luz0JKi7PlsR6tfy319JdTE7pDnBbOKqmRuxqxdwpGoOOvA5qq4w2KhwSNlVckSpOUB2gZI5JGa7Q6jYz+BIri4lLTlUt9gHRkyMn/AIDiuFp6zSrA0IciNiGK9ifWpsDbZoy3sOzahOQKom4kJzu/SrlxpSppNteJdq7ToWaPHKckYz+FZzAjg0WDVDy5fqaa/FCDvSsMikF7jQcilpDxxSU7CA8miiimAUUUUAfaqbfO2bAQqqcdOvTn8KjvfNe4aSYySoAN4cEISSc5YYwcdh71IlkZ7uO9E00ygM0SDCoobAy3qABgf7xNNtYZreKb+0JbeR3ZpgI3IUKRwGB9Bx6d66jyzOvS0d0jNGFR1Yo69BjljjOQBkAZqaMGKQAFm+XJywyfw61dW3kHzi0jC3DBjJIc+cfUA9R0HHBC0+C2iMzOBcee+AyOcIEB4YD35Oe4AxxQA+OOYDgplQMA4zgkd/z/ACrQt12WzSyzIir/AMsyeTnuT2H+NZoijtBaxaaks0c8pa5kmmDFchiXHfbkDA+taMjDYIysU20Dcj45IPcHjGR39KAIdT06+v7C4tNMgP2u7+WMBlQsx77jx09eOKrSpNEFs3UiaIBXUNuVSOCAw4POee9XcHZLNMPLlj+VCsm5Qmc/MMfe9u3NMlWUO67i+5t4VT7dcdqAKKZLMvIbj+tXLMxwRBPlCngZ6GmxW1oJS4DtcSf6wtJlNo+6AoHHfPrV2O3t1gT7SkZIfKFjkBscY9+tAmVpEilufLfOVA+62CeenoKpzx6Tc3Mz6hpZmQuAkdtMIUjX+IEd+Bgc9TmtS7Mau8YBI5O0LyDjk4H4cVn3It5wIYZ4sMDIQwB3EcfKQOn8zTQinp0EW/zFCCFXPysc7B1AHc4HetOCYvILZkkxEgIJjIQA8gZxjPP1qsYlSECFizs5DEKPlYHHy/SrupalFpPhq5uNR1BobC2DTz73OxT3bHdj0HcnAouBFe6jpWm6fLq19fRQ2NtD5s0hJ4GccAdecAepNfM/xg+I114x1mRWna30qF/9Fsg3GB0d8feY9eeB2pnx0+I8/i3UTpuliTTvD0DgW9luG+TaMCSUjjPXC9B9ea87by1I2kGs3NJnbTo2V2aD3kRbgsf+A1G99DnAV/fpVIt6Yph61DqM25UT3NwZXzgAAcCoWOTmkoqG7lJJBRRRSGWoruRLUwZBXtntVfk5zRGm4nnAHWrWlmB7oQzL8r8Kc9DSZTd0Vl4FANXr2GNHwnSqUuATikSNPWm0oNWNH0691XUYrDTraS4uZmwkaDJP+A96pAVgCTgAn6UV738I/AGn+GimpasY7nVFOVYfMlvx0XPU+/5VyPx/8FW+mXY8Q6HbLFp1wwW4hTpDIf4gOyt6dj9RVuDSuZqrFy5TzKpIo88mlhiLHJ6CpZGVFOevaiEb7lNn2otpCl7DJbRpBBBCYfJxtTAYbQfoAT+NJ9jaS0njvLeCWOd94D4PnpgYLY9xjB7AZqK4WwgBvYlSK7lVVaQyMYiOhBUd84HTPFMWNrZPLTV57oMwJeWJI/mz8yoozhewySa3POsWrV1dEYNJIu7bs3AKo/EZOO2PU0sUlqbiYJGoS3baRkYQgDBPPGBwM9qp3U6vqNvK1/Jbqj5CCPd57bT8h5GAc9e2BUFpcSNuhS0afzbh2l2ENhcnLsD2GMH2oCxt2YMiM9ucxTICXXBLr1PBx8uMe/PSp5UTzUeJEDuw8xmHJABwPfk/qaqC4ZTu2r947cY4HamF5XhVI3ZCrB5GbkgA5I/p7UAwe9iaz+0W6uY5JNrMqEck7SfXr3FRvdI/nPcw/IqqGGCCBgk5AOfxqZrqZsPLLc3EoO1GTLbF6fNjooXPoBVW2u7f7RJbrK0ki/vWilcfut3AAXspAzzQIt7LORDHBCkUci7XVcgBCPugnkdfrWhYSRyW0bQxiCMoCsZ+bYCOBzzWMtxvn3mHKICWbcBg/Tr0q7p1xGI1MZIwMgH7v40ASG0RbgiOS4klmAL+awClj0246KMd6dEILfzPIS3CIfnQ7flPsAMZyc4pgu8ytIwTKkjdtG4gdM+3X865f4kePtF8EW8Eupo0lxNlo7e0RfNlH98k8D0yfp2oGlfQ6XxJPYaTokmqapfLbW0EZMsrABYlxwR3Zj6Y5NfLvxz+J1x4y1VbbTw9tpFp8sERUK05/wCesmOrH06AVS+L/wARdW8dakok8y00yAgwWIl3Dd/fc8bm5+g7VxEmOgrOU+x00qKi7sRiSST1NJRRWJ1BRRRQAUUUUAFFFFABQCQcg4NFFAFw3QljG/hx19DVWTrTaKACvRP2fvEUGl6xPpcyRo9+P3U+0btw/gJ64Pp6153T7eWW3uEnhcpJEwZGHVSOhpp2dxSV1Y+p9NhFzvBlClhleetUvG0VlH4P1FNRO+1Fm7Sp1J44x75xivOPht8Rmur6307WfkldwqXK8Bj23DtXR/HK9lXwgturkC7uERyO6gFsfoK3TUjh5JRkrniqIAgwecVUuHDSHjpx1q5qTLEm0DDN+grPNRN20OyK6n2UdQ3KHkLLs+6xGAwxjIFRXc17bssN1FGsu3fshcOFUgFSW9dpGcevtVKN/tKt+9W3Kndkx8vj+EY9ex6d6rXBc7rgYVNxjABB56njOeMgc1qcBZe9ljkwr4XGJCvG5e/Xt0pdOvQIEDEbBFhtoOcY6H1PX681gyXdsVMY3XBZdw8sk+WxHDH2Azx0707R5FCoftBdx95Qu3bkD5QOeg9e9AHVR3vmw7vLLKcfIwKg9OCOMdauJEssYidE2oQVD528cjgc1h6fO8sjIN2Cu/zSN+3noPUn/wCvWzGTDAN7FjIQAM5Jyccj8aBMmXzo4htuAjHAl25+cdx9DQ11bixYQ2Ntk/O7+XiWY543MOTwMY9KZdW6xyrFahjuHAeUbge5yR068Y4qteFLeBJreZyX+dtyZVO2Mdxjn15oESLJYRQyXG+RbiY4kWVVEcaj7u0nkHk5/CrAlfJk+0b92NqlecepbofoBWXDdI0yubeKXymAMU0e5ZOc5ZT1H+FWHkmdS4UbpPmUFcY59B0H0oATWb+HTNJutTuJDtht5J5VyF+6MhQc85/rXyx401e+1zWZdR1Cd5ZpjuO48IOyqOyjoBXtvx/1H+zvAx0+NoxLqlxh/mO7YuGbAx0J2jOa8AuWBkJJzSbsb0o6XKre1Qk5JqVzkmou9YS3OuIUUUVJQUUUUAFFFFABRVqPTb+TS5NSS0lNpEwVp9vygntmqtABRRRQAUUUUAFFFFACgkEEEgjkEdq9K1rWv7d+HWjPNIDLAZBcsT3QAAn6g5rzSpftE/2X7N5reVu3bM8Z/wAiqjKxMo8wt9L51wzg8Hp9KhoopN3dylofV0YlIjaSQNJhfmY524Hr3xjp9BUdwA5PkRop/jZRgu2ep9Tj+VOaM/ahKZ+BEECAfL0zn61DAzOjHBXzJWLgjAGCRkflXSedZkMrSRtthh+yRx/IDEnlDJABHHOSAOPeqWjNiW8SUF5IjhD5mdoPRSRweBitB4JHDHcywlsIp+83oxPQg+vtVvU76KXRILRrWKGSxicvNEnM+4/eY46jHqf1oBqxb0hk8kQiYZCB8Fs7u2c4/Wtm0Ec3KkMUwN3pWHpc0KWMUW4RloVYoOcL0Bz1rUsYilqshcfPhipHbHAH6UCJJHkkv7YxxSFJA5ZwwwmB8ob689PSq+sFQiJLkFjlTn075FWZGeN4hDbYSRvMlZf+WYx1I9D0OORS35cwTyptLMu5N6gKpx0x6cd6CTMBjRGtoLt7wxAMzvCIyGYZ6An8Pp2qdlnMKsSE6AHP50lvDK5V5YmjGW8oEYJXpuIPIBxwe4omIR/MLFo41LyfMMKFB6etAHif7Rl+kvi/7Ckhf7BAEfnIEj/M2PwK15jM/QitfxZqEup6zdahKcvdzvMT9TkD8BisRvvGoZ2U4pRGt/q/rTKe4+SmVi9zdBRRRSGFFFFABToInmnSGJC7yMFVR1JPAFNrqfg9Zm68bRSgZ+xxNOMjIyOB+pFNK7E3ZXPU7jTrc+Av7HnQFo7AQsFXguq9fzFeCMpVipGCDg19GqCZAZcgFcMorw34j6bHpXjK9tYWLRF/MQkY4bnH6mtKisjnoyvJmHRRRWR0hRRSoMmgBKcihhzSlcUqE+nFVyslvsI6KFyKZUsn+rNRUmEQooopFH1JZXMEqNIshAwCgAzu7ck9OAecHpUOmsxup2Mg2CYhVDdRgH8O/wCtVLq5u5XDFsOzZckE9cdF6mq1oEB89vMjBlLjJwrkcZPfb9K6WziOiSEzp9njvIonfnz7gERxknnoDwPXFVdcdoNDkh89ZCrLGZADtlycbtvUDnNRW90rSY3LtBBAIySPp7+9WtIvY4dQinntbe6gO4zQXAYq4IIwCOnUH6DFCYNF+BWOnx2TsEWMBy6rtGRwBuPOPY+5xV+bTo7qyitrN5bQEh3aKVj5rA5JJPY+g9BWC1/ul8hQrKCGw0W6NsHuvT8K2NNvWuLYnIQpKV+ViA+D1+g/KmRIvRkxwOJnfcWwrkhycnjA6cZ9O1LqphsYJJJZXSIRqWIXOCWxge+T+tRQKhmVJRGxh2ndG2cE54PHp/Wppo9QW3kTWLaK2kZw0Sbg+Y8/KTgnBOM4+lBDGalctLcoZbiXf/eYFi6gYAye2P5VyXxn8TaV4b8Jvb21sgub2M29rHGQWjJQ7pGz9T78getdc73bhZvIZraQBWn3BsYOAP8AZ5HHrj0rw79pq+eXx9BZNbRwpYWKlNke3cZOc4x6AUF0480jzGeQu3J6cVXdcKTUuCSSahnchsColJI6o3uRsSeKSiisDYKKKKACiiigAr074D6YDpF/qT7laaZYEYDoqjc36lfyrzJFZ3CIpZmOAAMkn0r6D8GaM2j+E9P01lZJEhMsuO7tyx/Pj8KumtTKtK0TSmit4kihs5p5CVy7SL0PtXlPx1sf9PtdURTh1MMhx/EORn8M16j9rZSUikCkjkEdax/H2lJqvg26gZAskcZnDYzhxyBW0ldHJTnyyueDUUUVzHoBUiADpSRKOppxwK0gupLYMaT+EmlXpSSfcpSYkMJpKKKgsKKKKAPogXQMZmuMST5H7xpCSVx0I6fjVWwllksjIiL5aELnIJZjngDr61Ojw8RLHAVZCgUpkLx1AJ6jg57VDepp0EdtbWd1JGJwrTnYC0DDqBwNwwMjtyAea6G9TiWxdjn8qB49+WPDgJt3fh2+nSp7ScNGbdP9XI4BAXGcdMf59ax2cHftdjGG9Bn6/l2q7pdyBwAiBhgqg5655z/nigZbgnlj1BgrMqphw5JwD6jHXFbtvI+osDcXMjuqoiybsERryFHoOP1NYMsyBBCzMyBi+zOArEYLEjnA/KtHRd8bgTMU8zB+SI7kXPG4HjJHP0NUJq50UUFnaRF7JZGeZszvK4bJz/DgDCgHge9VI9SDaXDe2azBTCS5V/urj+I9+eDVW1vQ0b3LoYgCXk3clhycZ9e/40T6l/xMkkRYonKBlJUBYcAYyo7dM0GRDHrMkemyTzRj50adVbOCFXd82Og9zXzj4n1i+1/XrrV72V5JLuTI3sTtUcKoz2AwK9x8fa1e2vgrXJm1RrYalbPDNsxmYseF/FufpXgjFUcKCCIxj8qTOiktGQXB2AL3NVWOTk1NcsZXZ6grGe5vFWCiiioLCiiigAooooA6v4MWkF147gNwgcW8bTID03DGD+Gc/hXtklwsU7/P5ixDB2t19q8L+E8skPj2xMefn3q2P7pRs17LqE0QVI4dhLIC7H1ren8JyYj4kWJrhJbGODbbxoDjKj5zn1NMu1mawaENmGTgjP3qUSWaW0EUVsBIiZmlD7t309KryT+VIjRfvAshYg1ZgeBa1AbXWLq3Ix5czLj8arqMmul+LVoLfxlNOi4S7USj0yetc4grna1PQTvG4/qKTApaKbZIU2X7lI7c8GmlmPU1NykhKKKKRQUUUUAe+QyloNqTRhFVVCn75HYKcdKpzyrHcRp8zOWYsSeB6YHpgChGcNuiUKBgKWGBj6+tOAKyn5uXGHB67fr6/wCFbHHYnKxxOvmiGUXCl9iSHCDtkjHPt2zVq0jhWJnkuDC6r8qOhZp3zjAwPkAHPPoaq2wZofskahnkZQFC/O4HQA9Dk9fpS28ohOFOPNXhsdRnpz346iqTHZlm6ZreYou6SRwB8knAyORnv15/GtbSAZE81nYMCF2KpO7qCxfPQYxgDnPtWCEdpzKx2lBlUOQzA9Co7/X3FaOivGmWPysucAA5545/KmxG0wWDTLsxcvkvszweBkn2+lW9PuFXUZZYnQtGoJUxgkHHytkgg8dvaqmlSmC3LF2JL7ivU55Pb0FT+YssUzIE+99/P5g0zLlPKP2jLlmfS7SP5UlDyMBgAkYHQV5nJ8sZ55IxXoHx2EY1jTY+GnS3kLOMjK7uBj2+avPZjk4z0qGzspr3URg/Kajp2SAQO9NrF7miCiiikMKKKKACiiigDvfgro0pvX12dxDCitDAxGdzHhiPoOPxr0G8RQ7kksU5Ax96uL+B+pH+y73T3UOInDxgjOAw5/Va7DeAjBGIDdSTkn2reC905KybkPsHZEZmC4YbRTizXNwIYgokPPHApq5GI5PlOPumoppo8yHGCAfn9KsnkT3OJ+NcS/ZrGRgBKsjp9RiuCTpWp4t1STVtXklZ8xREpCM8bQev41lOQoyO1Yz3OmKajYVjtGajYkmhmLdaSsy0rBRRRQMKKKKACiiigD2q0YhSrKHWMDAwcf5FI+F/dklupbByDk+9UrKdTbEy7w3HliNhtzwDu9sf0pZZWjhSR3Rt52qEOCDk8kV02Rz2LxcJGYmJy2RjGTg+9FlcvE+4xRnfGy/Mu4rnuPQ+/aqbTPcMQmAAmWbcCVAwMjPuen09KmtHdIlkKxksGVVc5bGPvY7expcqCxp2+oSm2e1ZiVLAkk5JwMDnrgc8VbtHRAg+ZgwyTnB9/wAKxrp4RLm2ckYALvjLN7DsM9qtLcQruELytFgBmlAVs45Hy8DnOKYnG51NkALT5HJ3KSSW6YFStMRY7onQ716r0B/rWLptwiWUcUeQgAUKTkn6n+tSvPHG8UEh2DJyoYHPHTHfvTIcbHl3xreU+LUeUkqtoFTn1djXDsR0zXZ/G07vFsRVjte0QgnjOC1cXJ96sZvU6YL3UNJ7UmaXFBzWZYlGKKKACilHApKAClzSUUAdr8FpAuq30ZXJaBW6+jf/AF6753yxxIoGM9OleQeEdTl0vXYbhPusfLkH95WOD/j+FerO79yu1Rjit6b90xqLW5NFIRGex9fWuZ+KGrta6QlrC4Wa8BVwOojHU/iePzrb1C8itLFru5kCxxruI7n2ryrxBqU+qatLez9XOFX+4vYUSdkEI9SmxAT0phNDHmkrFu5sFFFFIAooooAKKKKACiiigD//2Q==";

static BOOL gAuthorized = NO;
static NSString *gCard = nil;
static NSString *gToken = nil;
static long long gExpire = 0;
static UIAlertController *gAlert = nil;
static NSTimer *gTimer = nil;

static NSString *MD5(NSString *s) {
    const char *c = [s UTF8String];
    unsigned char d[CC_MD5_DIGEST_LENGTH];
    CC_MD5(c, (CC_LONG)strlen(c), d);
    NSMutableString *r = [NSMutableString string];
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) [r appendFormat:@"%02x", d[i]];
    return r;
}

static NSData *RC4(NSData *in, NSString *key) {
    const uint8_t *k = (const uint8_t *)[key UTF8String];
    NSUInteger kl = [key lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    uint8_t s[256];
    for (int i = 0; i < 256; i++) s[i] = (uint8_t)i;
    int j = 0;
    for (int i = 0; i < 256; i++) {
        j = (j + s[i] + k[i % kl]) & 0xff;
        uint8_t t = s[i]; s[i] = s[j]; s[j] = t;
    }
    NSUInteger n = [in length];
    uint8_t *out = malloc(n ? n : 1);
    const uint8_t *p = (const uint8_t *)[in bytes];
    int i = 0; j = 0;
    for (NSUInteger x = 0; x < n; x++) {
        i = (i + 1) & 0xff;
        j = (j + s[i]) & 0xff;
        uint8_t t = s[i]; s[i] = s[j]; s[j] = t;
        out[x] = p[x] ^ s[(s[i] + s[j]) & 0xff];
    }
    return [NSData dataWithBytesNoCopy:out length:n freeWhenDone:YES];
}

static NSString *Hex(NSData *d) {
    const uint8_t *p = (const uint8_t *)[d bytes];
    NSMutableString *r = [NSMutableString string];
    for (NSUInteger i = 0; i < [d length]; i++) [r appendFormat:@"%02x", p[i]];
    return r;
}

static NSData *Unhex(NSString *s) {
    NSUInteger n = [s length] / 2;
    NSMutableData *d = [NSMutableData dataWithLength:n];
    uint8_t *p = (uint8_t *)[d mutableBytes];
    for (NSUInteger i = 0; i < n; i++) {
        unsigned int v = 0;
        sscanf([[s substringWithRange:NSMakeRange(i * 2, 2)] UTF8String], "%x", &v);
        p[i] = (uint8_t)v;
    }
    return d;
}

static NSString *DeviceCode(void) {
    NSString *idfv = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    if (!idfv.length) idfv = [[NSUUID UUID] UUIDString];
    return [MD5(idfv) substringToIndex:16];
}

static long long NowSec(void) {
    return (long long)[[NSDate date] timeIntervalSince1970];
}

static NSDictionary *Post(NSString *ident, NSString *card, NSString *token) {
    @autoreleasepool {
        NSMutableArray *keys = [NSMutableArray arrayWithObjects:@"kami", @"markcode", @"t", nil];
        NSMutableDictionary *p = [NSMutableDictionary dictionary];
        p[@"kami"] = card ?: @"";
        p[@"markcode"] = DeviceCode();
        p[@"t"] = [NSString stringWithFormat:@"%lld", NowSec()];
        if (token.length) { p[@"token"] = token; [keys addObject:@"token"]; }
        [keys sortUsingSelector:@selector(compare:)];
        NSMutableString *canon = [NSMutableString string];
        for (NSString *k in keys) [canon appendFormat:@"%@=%@&", k, p[k]];
        NSString *sign = MD5([canon stringByAppendingString:APPKEY]);
        NSString *plain = [canon stringByAppendingFormat:@"sign=%@&value=%d", sign, (arc4random() % 9999) + 1];
        NSString *data = Hex(RC4([plain dataUsingEncoding:NSUTF8StringEncoding], RC4KEY));
        NSString *body = [NSString stringWithFormat:@"app=%@&data=%@", APPID,
                          [data stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet alphanumericCharacterSet]]];
        if (token.length) {
            body = [body stringByAppendingFormat:@"&kami=%@&kamitoken=%@", card ?: @"", token];
        }
        NSString *url = [NSString stringWithFormat:@"%@?id=%@&app=%@", APIURL, ident, APPID];
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
        req.HTTPMethod = @"POST";
        req.timeoutInterval = 10;
        [req setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [req setValue:@"Dalvik/2.1.0" forHTTPHeaderField:@"User-Agent"];
        req.HTTPBody = [body dataUsingEncoding:NSUTF8StringEncoding];
        __block NSData *resp = nil;
        dispatch_semaphore_t sem = dispatch_semaphore_create(0);
        [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *d, NSURLResponse *r, NSError *e) {
            resp = d;
            dispatch_semaphore_signal(sem);
        }] resume];
        dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 12 * NSEC_PER_SEC));
        if (!resp.length) return nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:resp options:0 error:nil];
        if (!json) {
            NSData *dec = RC4(Unhex([[NSString alloc] initWithData:resp encoding:NSUTF8StringEncoding]), RC4KEY);
            if (dec) json = [NSJSONSerialization JSONObjectWithData:dec options:0 error:nil];
        }
        return json;
    }
}

static NSString *Str(id v) {
    if (!v || v == [NSNull null]) return @"";
    return [NSString stringWithFormat:@"%@", v];
}

static long long ParseTime(id v) {
    if (!v || v == [NSNull null]) return 0;
    if ([v isKindOfClass:[NSNumber class]]) {
        long long n = [v longLongValue];
        if (n > 100000000000LL) n /= 1000;
        return n;
    }
    NSString *s = Str(v);
    if ([s containsString:@"永久"]) return 0;
    long long n = [s longLongValue];
    if (n > 0) { if (n > 100000000000LL) n /= 1000; return n; }
    NSDateFormatter *f = [[NSDateFormatter alloc] init];
    f.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSDate *d = [f dateFromString:s];
    return d ? (long long)[d timeIntervalSince1970] : 0;
}

static void LoadState(void) {
    NSUserDefaults *u = [NSUserDefaults standardUserDefaults];
    gCard = [u stringForKey:@"dt_card"];
    gToken = [u stringForKey:@"dt_token"];
    gExpire = [u longLongForKey:@"dt_expire"];
}

static void SaveState(NSString *card, NSDictionary *msg, NSString *token, long long expire) {
    NSUserDefaults *u = [NSUserDefaults standardUserDefaults];
    if (card) { gCard = card; [u setObject:card forKey:@"dt_card"]; }
    if (token.length) { gToken = token; [u setObject:token forKey:@"dt_token"]; }
    if (expire > 0) { gExpire = expire; [u setLongLong:expire forKey:@"dt_expire"]; }
    NSString *gg = Str(msg[@"app_gg"]);
    if (gg.length) [u setObject:gg forKey:@"dt_notice"];
    [u synchronize];
}

static BOOL LocallyValid(void) {
    return gCard.length >= 4 && (gExpire <= 0 || NowSec() < gExpire);
}

static void StartHeartbeat(void);

static void PresentLogin(NSString *tip) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (gAlert) return;
        UIWindow *w = UIApplication.sharedApplication.keyWindow;
        if (!w) return;
        gAlert = [UIAlertController alertControllerWithTitle:@"卡密验证"
                                                    message:tip ?: @"请输入卡密激活模块"
                                             preferredStyle:UIAlertControllerStyleAlert];
        [gAlert addTextFieldWithConfigurationHandler:^(UITextField *tf) {
            tf.placeholder = @"请输入卡密";
            tf.text = gCard;
        }];
        UIAlertAction *verify = [UIAlertAction actionWithTitle:@"验证" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
            NSString *card = gAlert.textFields.firstObject.text;
            gAlert = nil;
            dispatch_async(dispatch_get_global_queue(0, 0), ^{
                NSDictionary *j = Post(@"kmlogon", card, nil);
                int code = [j[@"code"] intValue];
                NSDictionary *msg = [j[@"msg"] isKindOfClass:[NSDictionary class]] ? j[@"msg"] : nil;
                if (code == 200) {
                    long long exp = ParseTime(msg[@"vip"] ?: j[@"vip"]);
                    NSString *tk = Str(msg[@"token"] ?: msg[@"kamitoken"] ?: j[@"token"]);
                    SaveState(card, msg, tk, exp);
                    gAuthorized = YES;
                    StartHeartbeat();
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UIWindow *w = UIApplication.sharedApplication.keyWindow;
                        UIAlertController *ok = [UIAlertController alertControllerWithTitle:@"验证成功"
                                                                                   message:(exp > 0 ? [NSString stringWithFormat:@"到期：%@", [NSDateFormatter localizedStringFromDate:[NSDate dateWithTimeIntervalSince1970:exp] dateStyle:NSDateFormatterMediumStyle timeStyle:NSDateFormatterShortStyle]] : @"已激活")
                                                                            preferredStyle:UIAlertControllerStyleAlert];
                        [ok addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
                        [w.rootViewController presentViewController:ok animated:YES completion:nil];
                    });
                } else {
                    NSString *m = msg ? Str(msg[@"msg"]) : Str(j[@"msg"]);
                    if (!m.length || [m isEqualToString:@"null"]) m = [NSString stringWithFormat:@"验证失败(code=%d)", code];
                    PresentLogin(m);
                }
            });
        }];
        [gAlert addAction:verify];
        [gAlert addAction:[UIAlertAction actionWithTitle:@"解绑设备" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
            NSString *card = gAlert.textFields.firstObject.text;
            gAlert = nil;
            dispatch_async(dispatch_get_global_queue(0, 0), ^{
                NSDictionary *j = Post(@"kmdismiss", card, nil);
                NSString *m = Str(j[@"msg"]);
                PresentLogin(m.length ? m : @"解绑完成");
            });
        }]];
        [gAlert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) {
            gAlert = nil;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (!gAuthorized) PresentLogin(nil);
            });
        }]];
        [w.rootViewController presentViewController:gAlert animated:YES completion:nil];
    });
}

static void StartHeartbeat(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [gTimer invalidate];
        gTimer = [NSTimer scheduledTimerWithTimeInterval:5.0 repeats:YES block:^(NSTimer *t) {
            dispatch_async(dispatch_get_global_queue(0, 0), ^{
                NSDictionary *j = Post(@"heartbeat", gCard, gToken);
                int code = [j[@"code"] intValue];
                if (j && code == 200) {
                    NSDictionary *msg = [j[@"msg"] isKindOfClass:[NSDictionary class]] ? j[@"msg"] : nil;
                    long long exp = ParseTime(msg[@"vip"] ?: j[@"vip"]);
                    SaveState(nil, msg, nil, exp);
                    gAuthorized = YES;
                } else if (j) {
                    gAuthorized = NO;
                    PresentLogin(@"授权已失效，请重新验证");
                }
            });
        }];
    });
}

static UIImage *AvatarImage(void) {
    NSData *d = [[NSData alloc] initWithBase64EncodedString:kAvatarB64 options:0];
    return d ? [UIImage imageWithData:d] : nil;
}

static void StyleAuthorView(UIView *v) {
    for (UIView *sub in v.subviews) {
        if ([sub isKindOfClass:[UILabel class]]) {
            UILabel *l = (UILabel *)sub;
            NSString *t = l.text ?: @"";
            if ([t containsString:@"完全免费"] || [t containsString:@"TG交流群"] || [t containsString:@"基于DYYY"] || [t containsString:@"DYYY"]) {
                sub.hidden = YES;
            }
        }
        if ([sub isKindOfClass:[UIButton class]]) {
            UIButton *b = (UIButton *)sub;
            NSString *t = [b titleForState:UIControlStateNormal] ?: @"";
            if ([t containsString:@"TG交流群"] || [t containsString:@"基于DYYY"] || [t containsString:@"DYYY"]) {
                sub.hidden = YES;
            }
            if ([t containsString:@"关于作者"] || [t containsString:@"联系作者"]) {
                [(UIControl *)sub removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
                [b addTarget:[UIApplication sharedApplication] action:@selector(_dt_showWechat) forControlEvents:UIControlEventTouchUpInside];
            }
        }
        if ([sub isKindOfClass:[UIImageView class]]) {
            UIImage *img = AvatarImage();
            if (img && sub.bounds.size.width > 30) ((UIImageView *)sub).image = img;
        }
        StyleAuthorView(sub);
    }
}

@interface UIApplication (DT)
- (void)_dt_showWechat;
@end

@implementation UIApplication (DT)
- (void)_dt_showWechat {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"联系作者" message:[NSString stringWithFormat:@"微信：%@", WECHAT] preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"复制" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
        UIPasteboard.generalPasteboard.string = WECHAT;
    }]];
    [a addAction:[UIAlertAction actionWithTitle:@"关闭" style:UIAlertActionStyleCancel handler:nil]];
    [UIApplication.sharedApplication.keyWindow.rootViewController presentViewController:a animated:YES completion:nil];
}
@end

@interface DYZSAuthorInfoView : UIView
@end

%hook DYZSAuthorInfoView
- (void)layoutSubviews {
    %orig;
    StyleAuthorView(self);
}
%end

%ctor {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!objc_getClass("DYZSAuthorInfoView")) return;
        LoadState();
        if (LocallyValid()) {
            gAuthorized = YES;
            StartHeartbeat();
        } else {
            PresentLogin(nil);
        }
    });
}
